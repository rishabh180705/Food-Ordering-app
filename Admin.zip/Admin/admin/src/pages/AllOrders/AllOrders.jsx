import React from 'react'
import './AllOrders.css'
const AllOrders = () => {
  return (
    <div>
      
    </div>
  )
}

export default AllOrders
