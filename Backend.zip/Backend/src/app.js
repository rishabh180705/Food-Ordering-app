import express from "express";
import cors from "cors";
import foodRouter from "../routes/foodRoute.js";
import userRoute from "../routes/userRoute.js";
import { checkForAuth } from "../middleware/auth.js";


const app = express();
app.use(express.json());
app.use(cors({
    origin: ['http://localhost:5173', 'http://localhost:5174'], // Array of allowed origins
    credentials: true, // Allow cookies and credentials
  }));
  app.use(checkForAuth);
  


// api endpoints
app.use('/api/food',foodRouter);
app.use('/api/user',userRoute)
app.use(checkForAuth('token')); // Check for authentication middleware





export { app };