import React from 'react'
import './Order.css'

const Order = () => {
  return (
    <div>
      
    </div>
  )
}

export default Order
